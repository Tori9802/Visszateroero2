<?php
    include '../Galeria/csatol/kapcsolat.php';
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Visszatérő Erő Sportegyesület weboldala" />
    <meta name="author" content="Visszatérő Erő Sport Egyesület." />

  
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
	<link rel="manifest" href="site.webmanifest">
	<link rel="mask-icon" href="safari-pinned-tab.svg" color="#5bbad5">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="theme-color" content="#ffffff">

  
    <title>Visszatérő Erő Sportegyesület</title>

    <!-- Ikonkészlet -->
    <script src="assets/fa-all.js"></script>
    <!-- Bootrsap CSS -->
    <link href="assets/bootstrap.css" rel="stylesheet" />


    <link href="visszatero.css" rel="stylesheet" />
</head>

<body id="page-top">

    <!-- Navigáció -->
    <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand js-scroll-trigger" href="#page-top">Visszatérő Erő Sport Egyesület</a>
            <button
                class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded"
                type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive"
                aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
               
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger"
                            href="index.php">Kezdőlap</a>
                    </li>
                    <li class="nav-item "><a class="nav-link rounded js-scroll-trigger" href="#rolunk">Rólunk</a>
                    </li>
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../naptar/index.html">Naptár</a>
                    </li>
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="#tamogatoink">Támogatóink</a>
                    </li>
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../Galeria/index.php">Galéria</a>
                    </li>
					                   
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="#kapcsolat">Kapcsolat</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Fejléc -->
    <header class="masthead bg-primary text-white text-center">
        <div class="container d-flex align-items-center flex-column">
            <!-- Masthead Avatar Image-->
            <img class="masthead-avatar mb-5" src="assets/img/received_962114184397551.jpeg" alt="Logó" />
            <!-- Masthead Heading-->
          <h1><strong>Visszatérő Erő Sport Egyesület</strong>            <!-- Icon Divider-->          </h1>
          <div class="divider-custom divider-light">
            <div class="divider-custom-line"></div>
                <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                <div class="divider-custom-line"></div>
          </div>
            <!-- Masthead Subheading-->
            <p class="masthead-subheading font-weight-light mb-0">
				Hírek: 
            <section id="rolunk-felirat"><font size="-1">
              <?php
    $kategoria_sql = "SELECT * FROM hirek";
    $kategoria_keres = $conn -> query($kategoria_sql);
    if ($kategoria_keres -> num_rows > 0){
        
        while ($egyKat = $kategoria_keres->fetch_assoc()){
            
?>
              <div class="row">
                <div class="col">
                    <h2><?php echo $egyKat['neve'] ?></h2>
                    <p><?php echo $egyKat['leiras'] ?></p>
                </div>
            </div>         
 <?php           
        }
        
    }
    else {
?>
            <div class="row">
                <div class="col"></div>
            </div>
<?php            
    }
    
?>  </font></section>          
        </div>
		 </div></p>
      </div>
    </header>


    <!-- Támogatók -->
    <section class="page-section szolgaltatasok" id="tamogatoink">
        <div class="container">
            <h2 class="page-section-heading text-center text-uppercase text-secondary">TÁMOGATÓINK</h2>
            <div class="divider-custom">
                <div class="divider-custom-line"></div>
                <div class="divider-custom-icon">
                  <p><i class="fas fa-star"></i></p>
                   </div>
                <div class="divider-custom-line"></div>
            </div>
            <!-- elemek -->
            <div class="row">
                <div class="col-md-4">
                    <div class="szolgaltatasok-item mx-auto" data-toggle="modal" data-target="#szolgaltatasokModal1">
                        <div
                            class="szolgaltatasok-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                            <div class="szolgaltatasok-item-caption-content text-center text-white"><i
                                    class="fas fa-plus fa-3x"></i></div>
                        </div>
                        <img class="img-fluid" src="assets/img/szolgaltatasok/logoBUDDHAGYM (Kicsi).png"
                            alt="buddhagymtata" />
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="szolgaltatasok-item mx-auto" data-toggle="modal" data-target="#szolgaltatasokModal2">
                        <div
                            class="szolgaltatasok-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                            <div class="szolgaltatasok-item-caption-content text-center text-white"><i
                                    class="fas fa-plus fa-3x"></i></div>
                        </div>
                        <img class="img-fluid" src="assets/img/szolgaltatasok/logo-ok.jpg"
                            alt="johazikft" />
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="szolgaltatasok-item mx-auto" data-toggle="modal" data-target="#szolgaltatasokModal3">
                        <div
                            class="szolgaltatasok-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                            <div class="szolgaltatasok-item-caption-content text-center text-white"><i
                                    class="fas fa-plus fa-3x"></i></div>
                        </div>
                        <img class="img-fluid" src="assets/img/szolgaltatasok/tonoesfiaikft.png"
                            alt="tonoesfiai" />
                    </div>
                </div>
				
				<div class="col-md-4">
                  <p><p><p><p><p><p>
					<div class="szolgaltatasok-item mx-auto" data-toggle="modal" data-target="#szolgaltatasokModal4">
                    <div
                            class="szolgaltatasok-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                            <div class="szolgaltatasok-item-caption-content text-center text-white"><i
                                    class="fas fa-plus fa-3x"></i></div>
                      </div><p><p><p><p><p><p>
                      <img src="assets/img/szolgaltatasok/derik.png"
                            alt="derik" width="270" height="68" class="img-fluid" />
                    </div>
                </div>
				
            </div>
        </div>
    </section>

    <!-- Rólunk -->
    <section class="page-section bg-primary text-white mb-0" id="rolunk">
        <div class="container">

            
            <h2 id="rolunk-felirat">RÓLUNK</h2>

            <div class="divider-custom divider-light">
                <div class="divider-custom-line"></div>
                <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                <div class="divider-custom-line"></div>
            </div>

            <div class="row">
				 <div class="col-lg-4 ml-auto">
                                    <p>A <strong>Visszatérő Erő Sport Egyesület</strong>et 2019. júniusában hoztuk létre, hogy esélyt adjunk másoknak.<p> Az egyesület megalapításához azok az élmények inspiráltak, amelyeket a versenyzés elkezdésekor átéltem. <p>Profi sportolóként pedig kötelességem példát mutatni, és felkutatni az ijfú tehetségeket. <p>A Visszatérő Erő egy teljesen hivatalos egyesület, amely magába foglalja a Karbirkózást és az Erőemelést. Jelenleg támogatókat keresünk, hogy minél több versenyre el tudjon jutni a csapat! - Sztanek Sándor</p>
                </div>
                <div class="col-lg-4 mr-auto">
                    <h3>
                  Tagsági díjak</h3>
                    <p>Egyéni tagsági díjak 2023</p>
                    <p>I. Diák kategória - éves díj 15.000 forint</p>
                    <p> II. Felnőtt kategória - éves díj 20.000 forint                      </p>
                    <p>III. Nyugdíjas kategória - éves díj 10.000 forint </p>
                </div>

               
                <div class="col-lg-4 mr-auto">
                    <p>Írjon nekünk az alábbi űrlap segítségével!</p>
                </div>
            </div>

        </div>
    </section>

    <!-- Kapcsolat -->
    <section class="page-section" id="kapcsolat">
        <div class="container">

            <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Kapcsolat</h2>


            <div class="divider-custom">
                <div class="divider-custom-line"></div>
                <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                <div class="divider-custom-line"></div>
            </div>

            <p class="lead ">Kérjük, töltse ki az alábbi jelentkezési lapot, és egy munkatársunk hamarosan felveszi
                Önnel a kapcsolatot.</p>

            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <form id="contactForm" name="sentMessage">
                        <div class="control-group">
                            <div class="form-group floating-label-form-group controls mb-0 pb-2">
                                <input class="form-control" id="name" type="text" placeholder="Név" />
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="form-group floating-label-form-group controls mb-0 pb-2">
                                <input class="form-control" id="email" type="text" placeholder="E-mail cím" />
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="form-group floating-label-form-group controls mb-0 pb-2">
                                <input class="form-control" id="phone" type="text" placeholder="Telefonszám" />
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="form-group floating-label-form-group controls mb-0 pb-2">
                                <textarea class="form-control" id="message" rows="2"
                                    placeholder="Üzenet:"></textarea>
                            </div>
                        </div>
                        <br />
                        <div class="form-group">
                            <button class="btn btn-primary btn-xl" id="sendMessageButton" type="button"
                                onclick="velemenyKuldes()">Üzenet küldése
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer-->
    <footer class="footer text-center">
        <div class="container">
            <div class="row">

                <div class="col-lg-4 mb-5 mb-lg-0">
                    <h4 class="text-uppercase mb-4">Egyéb elérhetőségeink:</h4>
                    <a class="btn btn-outline-light btn-social mx-1" href="https://www.facebook.com/AVisszateroEroSE"><i
                            class="fab fa-fw fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light btn-social mx-1" href="https://www.youtube.com/channel/UCrMR1P3YstaIVlz-ryOrnxw"><i class="fab fa-fw fa-youtube"></i></a>
                    
                    <a class="btn btn-outline-light btn-social mx-1" href="https://www.tiktok.com/@armwrestlinghungary"><i class="fab fa-fw fa-dribbble"></i></a>
                </div>

                <div class="col-lg-8">
                   <h5 class="text-uppercase mb-4"><a href="../galeria/admin/index.php">Adminisztrációs felület</a></h4>
                    <h4 class="text-uppercase mb-4">Tudta?</h4>
                    <p class="lead mb-0 text-left"> Amíg ezen a weboldalon tartózkodott, összesen <span id="szamlalo">0</span> ember szkanderezett a környékünkön*! Ha Ön köztük van, vagy szeretne szkanderezni, akkor keressen minket!
                  A részletekről érdeklődjön a jelentkezési lapon! </p>
                    <p class="lead mb-0 text-left"><font size="-1">*ez csak poén :)</font></p>
                </div>
            </div>
        </div>
    </footer>

    <div class="copyright py-4 text-center text-white">
        <div class="container"><small>Visszatérő Erő Sportegyesület ©2023</small></div>
    </div>

    <div class="scroll-to-top d-lg-none position-fixed">
        <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top"><i
                class="fa fa-chevron-up"></i></a>
    </div>

    <!-- Támogatóink felugró kártyái-->
    <!--  felugró kártya -->
    <div class="szolgaltatasok-modal modal fade" id="szolgaltatasokModal1" tabindex="-1" role="dialog"
        aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"><i class="fas fa-times"></i></span>
                </button>
                <div class="modal-body">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">

                                <h2 class="szolgaltatasok-modal-title text-secondary text-uppercase text-center mb-0">
                                    Buddha Gym
                              </h2>

                                <div class="divider-custom">
                                    <div class="divider-custom-line"></div>
                                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                    <div class="divider-custom-line"></div>
                                </div>

                                <div class="row justify-content-center">
                                    <a href="https://buddhagym.hu/"><img class="img-fluid rounded mb-5" src="assets/img/modals/logoBUDDHAGYM.png"
                                        alt="buddhagymtata" /></a>
                                </div>

                                <p>Edzőtermünk és három aerobic termünk professzionális felszereltséggel, kiváló szakemberekkel várja mindazokat, akik a mozgás, a sport és az egészséges életmód örömét keresik.  </p>
                                <button class="btn btn-primary" data-dismiss="modal">
                                    <i class="fas fa-times fa-fw"></i>
                                    Bezár
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Beléptetés felugró kártya -->
    <div class="szolgaltatasok-modal modal fade" id="szolgaltatasokModal2" tabindex="-1" role="dialog"
        aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"><i class="fas fa-times"></i></span>
                </button>
                <div class="modal-body">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">

                                <h2 class="szolgaltatasok-modal-title text-secondary text-uppercase text-center mb-0">
                                    Jóházi Kft
                              </h2>

                                <div class="divider-custom">
                                    <div class="divider-custom-line"></div>
                                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                    <div class="divider-custom-line"></div>
                                </div>

                                <div class="row justify-content-center"><a href="https://johazi.hu/">
                                    <img class="img-fluid rounded mb-5" src="assets/img/modals/logo-ok.jpg"
                                        alt="johazikft" /></a>
                                </div>

                                <p>Jó szerszám, jó munka, Jóházi - Sok éves tapasztalattal állunk megrendelőink rendelkezésére.</p>
                                <button class="btn btn-primary" data-dismiss="modal">
                                    <i class="fas fa-times fa-fw"></i>
                                    Bezár
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--  felugró kártya -->
    <div class="szolgaltatasok-modal modal fade" id="szolgaltatasokModal3" tabindex="-1" role="dialog"
        aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"><i class="fas fa-times"></i></span>
                </button>
                <div class="modal-body">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">

                                <h2 class="szolgaltatasok-modal-title text-secondary text-uppercase text-center mb-0">
                                    Tonó és fiai Kft.
                                </h2>

                                <div class="divider-custom">
                                    <div class="divider-custom-line"></div>
                                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                    <div class="divider-custom-line"></div>
                                </div>

                                <div class="row justify-content-center">
                                    <img class="img-fluid rounded mb-5" src="assets/img/modals/tonoesfiaikft.png"
                                        alt="tonoesfiai" />
                                </div>

                                <p>Fűtés- és vízhálózat szerelés, gázszerelés</p>
                                <button class="btn btn-primary" data-dismiss="modal">
                                    <i class="fas fa-times fa-fw"></i>
                                    Bezár
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	  <!--  felugró kártya -->
    <div class="szolgaltatasok-modal modal fade" id="szolgaltatasokModal4" tabindex="-1" role="dialog"
        aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"><i class="fas fa-times"></i></span>
                </button>
                <div class="modal-body">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">

                                <h2 class="szolgaltatasok-modal-title text-secondary text-uppercase text-center mb-0">
                                    D'Erik
                              </h2>

                                <div class="divider-custom">
                                    <div class="divider-custom-line"></div>
                                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                    <div class="divider-custom-line"></div>
                                </div>

                                <div class="row justify-content-center"><a href="https://www.derik.hu/">
                                    <img class="img-fluid rounded mb-5" src="assets/img/modals/derik.png"
                                        alt="derik" /></a>
                                </div>

                                <p>Biztonságtechnika. Cégeknek és magánszemélyeknek. </p>
                                <button class="btn btn-primary" data-dismiss="modal">
                                    <i class="fas fa-times fa-fw"></i>
                                    Bezár
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap, és függőségei -->
    <script src="assets/jquery.min.js"></script>
    <script src="assets/bootstrap.bundle.min.js"></script>
    <script src="assets/jquery.easing.min.js"></script>

    <!-- Téma-specifikus szkriptek -->
    <script src="assets/scripts.js"></script>

  
    <script src="visszatero.js"></script>

</body>

</html>