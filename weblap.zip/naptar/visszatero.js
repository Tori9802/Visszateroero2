
var velemenyKuldes = function () {
    var xmlhttp = new XMLHttpRequest();
    var nevInput = document.getElementById("name");
    var emailInput = document.getElementById("email");
    var telInput = document.getElementById("phone");
    var uzenetInput = document.getElementById("message");

    if (nevInput.value === "" || emailInput.value === "" || telInput.value === "" || uzenetInput.value === "") {
        alert("Kérjük, minden mezőt töltsön ki az űrlapon!");
        return;
    }

    xmlhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            nevInput.value = "";
            emailInput.value = "";
            telInput.value = "";
            uzenetInput.value = "";
            alert("Munkatársunk hamarosan keresni fogja önt!");
        }
    };
    xmlhttp.open('POST', '/api/kapcsolat');
    xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xmlhttp.send(JSON.stringify({
        name: nevInput.value,
        email: emailInput.value,
        phone: telInput.value,
        message: uzenetInput.value
    }));
};



var counter = 0;

function szamlaloStart() {
    setInterval(() => {
        counter++;
        var szamlaloSzoveg = document.getElementById('szamlalo');
        szamlaloSzoveg.textContent = counter;
    },
        500, window
    );
}

window.onload = function () {
    szamlaloStart();
};
