<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Visszatérő Erő Sportegyesület weboldala" />
    <meta name="author" content="Visszatérő Erő Sport Egyesület." />

  
    <link rel="apple-touch-icon" sizes="180x180" href="../../web/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="../../web/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="../../web/favicon-16x16.png">
	<link rel="manifest" href="site.webmanifest">
	<link rel="mask-icon" href="safari-pinned-tab.svg" color="#5bbad5">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="theme-color" content="#ffffff">

  
    <title>Visszatérő Erő Sportegyesület</title>

    <!-- Ikonkészlet -->
    <script src="../../web/assets/fa-all.js"></script>
    <!-- Bootrsap CSS -->
    <link href="../../web/assets/bootstrap.css" rel="stylesheet" />


    <link href="../../web/visszatero.css" rel="stylesheet" />
</head>

<body id="page-top">

    <!-- Navigáció -->
    <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand js-scroll-trigger" href="#page-top">Visszatérő Erő Sport Egyesület</a>
            <button
                class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded"
                type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive"
                aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
               
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger"
                            href="../../web/index.php">Kezdőlap</a>
                    </li>
                    <li class="nav-item "><a class="nav-link rounded js-scroll-trigger" href="../../web/index.php#rolunk">Rólunk</a>
                    </li>
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../../naptar/index.html">Naptár</a>
                    </li>
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../../web/index.php#tamogatoink">Támogatóink</a>
                    </li>
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../index.php">Galéria</a>
                    </li>
					                   
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../../web/index.php#kapcsolat">Kapcsolat</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Fejléc -->
    <header class="masthead bg-primary text-white text-center">
        <div class="container d-flex align-items-center flex-column">
            <!-- Masthead Avatar Image-->
                       <!-- Masthead Heading-->
          <h1><strong>Visszatérő Erő Sport Egyesület</strong></h1>
            
            <!-- Icon Divider-->
            <div class="divider-custom divider-light">
                <div class="divider-custom-line"></div>
                <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                <div class="divider-custom-line"></div>
          </div>
            <!-- Masthead Subheading-->
            <p class="masthead-subheading font-weight-light mb-0">Képek adminisztrálása</p>
      </div>
    </header>
<?php
    include '../csatol/kapcsolat.php';
    session_start();
    
    if (!isset($_SESSION['admin'])) header("Location: ../index.php");

    if (isset($_POST['regi_kategoria'])){
        $kat_id = $_POST['regi_kategoria'];
       
        $kat_sql = "SELECT * FROM kategoria WHERE id = '$kat_id'";
        $kat_keres = $conn->query($kat_sql);
        $kategoria = $kat_keres->fetch_assoc();

        $_SESSION['kategoria_neve'] = $kategoria['neve'];
        $_SESSION['kategoria_id'] = $kat_id;
    } 
    
    if (isset($_POST['uj_kategoria'])) {
        $kat_neve = $_POST['ujKat'];
        $kat_leiras = $_POST['leiras'];

        $konyvtar = "../kepek/" . $kat_neve;
        $konyvtar = mb_convert_encoding($konyvtar, "ISO-8859-1", "UTF-8");
        if (!mkdir($konyvtar, 0777, true)) {
            $uzenet = "Hiba történt a fájl feltöltésekor.";
        }
        else {
            $kat_beszur = "INSERT INTO kategoria (neve, leiras) VALUES ('$kat_neve', '$kat_leiras')";
            $keres_kat = $conn->query($kat_beszur);
            if ($keres_kat) {
                $kat_id = $conn->insert_id;  //az utoljára beszúrt sor id-jét mondja meg
                $uzenet = "A kategória létrehozása sikeres.";
                $_SESSION['kategoria_neve'] = $kat_neve;
                $_SESSION['kategoria_id'] = $kat_id;
            }
            else {
                $uzenet = "A kategória adatbázisba mentése sikertelen.";
                rmdir($konyvtar);  //ha nem sikerült felvenni az adatbázisba, akkor törli a könyvtárat
            }
        }

    }
    
    if (isset($_POST['feltolt'])){
        $target= "../kepek/" . $_SESSION['kategoria_neve'] . "/"; //célmappa
        $target = mb_convert_encoding($target, "ISO-8859-1", "UTF-8");
        $file_name = $_FILES['file']['name']; //a célfájlt nevezze el a $_FILES superglobal változóban lévo fájlnévre (a fájl eredeti nevére)
        $file_name = mb_convert_encoding($file_name, "ISO-8859-1", "UTF-8");
        
        $tmp_dir = $_FILES['file']['tmp_name']; //az ideiglenes mappa helyét a $tmp_dir változóban tároljuk

        if(!preg_match('/(gif|jpe?g|png)$/i', $file_name)) //ha a fájlnak ($file_name-nek) a kiterjesztése nem gif, jpg/jpeg, png, akkor...
        {
            $uzenet = "Rossz fajltipus!"; //hibaüzenet
        }
        else {
            $kat_id = $_SESSION['kategoria_id'];
            $sql = "SELECT * FROM kepek WHERE neve = '$file_name' and kategoria_id = '$kat_id'";
            $result = $conn->query($sql);
            if ( $result -> num_rows > 0) {
                $uzenet = "Ezzel a fáljnévvel már van kép a könyvtárban";
            }
            else {
                $feltolt = move_uploaded_file($tmp_dir, $target . $file_name); //az ideiglenes mappából átteszi a fájlt a végleges mappába (a $target . $file_name összeilleszti a két stringet, így uploads/fajlnev-et kapunk)
                if ($feltolt){
                    $kat_id = $_SESSION['kategoria_id'];
                    
                    $utso_sql = "SELECT MAX(sorszam) FROM kepek WHERE kategoria_id = '$kat_id'";
                    $utso_keres = $conn -> query($utso_sql);
                    $utso_sorszam = $utso_keres -> fetch_array();
                    if ($utso_sorszam[0] != null){
                        $sorszam = $utso_sorszam[0] + 1;
                    }
                    else {
                        $sorszam = 1;
                    }
                    
                    $sql = "INSERT INTO kepek (neve, kategoria_id, sorszam) VALUES ('$file_name', '$kat_id', '$sorszam')";
                    $result = $conn->query($sql);
                    if ($result){
                        $uzenet = "A kép feltöltve a könyvtárba.";
                    }
                    else {
                        $uzenet = "A kép feltöltve, de az adatbázisba töltés sikertelen. Próbáld újra. ide még kell valami - ki kellene törölni a képet a könyvtárból.";
                    }
                }
                else {
                    $uzenet = "A képfájl feltöltése nem sikerült.";
                    unset($file_name);
                }
            }
        }    
    }
    
    if (isset($_GET['katValt'])){
        unset($_SESSION['kategoria_neve']);
        unset($_SESSION['kategoria_id']);
    }
?>


  <section class="page-section" id="kapcsolat">
        <div class="container">
<h2>Képek feltöltése</h2>
<?php
    if (isset($_SESSION['kategoria_id'])){
?>
        <h2>Kép feltöltése a kategóriához</h2>
        <h3><?php echo $_SESSION['kategoria_neve'] ?></h3>
        <form method="post" action="<?php print $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
            <input type="hidden" name="MAX_FILE_SIZE" value="2000000"> <!--a feltöltött file maximális mérete 1mb-->
            <input id="file" type="file" name="file">
            <input type="submit" name="feltolt" value="Feltöltöm">
        </form>
        
<?php
    }
    else {
        $kategoria_sql = "SELECT * FROM kategoria";
        $keres_kategoria = $conn->query($kategoria_sql);
        
        
?>
        <h2>Kategória kiválasztása</h2>
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
<?php 
        if ($keres_kategoria->num_rows > 0){
?>
            <p>
                <select name="regi_kategoria">
                    <option value="0">válassz kategóriát...</option>
<?php
                while ($egyKat = $keres_kategoria->fetch_assoc()){
?>
                    <option value="<?php echo $egyKat['id'] ?>"><?php echo $egyKat['neve'] ?></option>
<?php
                }
?>                
                </select>
            </p>
            <p>
                <input type="submit" value="Kiválasztom">
            </p>
        </form>
<?php
        }
?>
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">    
            <p>
                Új kategória felvétele: <input type="text" name="ujKat" size="25">
            </p>
            <p>
                Leírás: <textarea name="leiras" rows="5" cols="50"></textarea>
            </p>
            <p>
                <input type="submit" value="Kategória mentése" name="uj_kategoria">
            </p>
        </form>
<?php
    }
?>
        <p><?php if (isset($uzenet)) echo $uzenet ?></p>
        <p>
            <a href="<?php print $_SERVER['PHP_SELF']; ?>?katValt=1">Másik kategória kiválasztása</a> 
        </p>
        <p>
            <a href="index.php">Vissza az adminisztrációs felületre </a>
        </p>
<p>
	</session>
		<!-- Footer-->
    <footer class="footer text-center">
        <div class="container">
            <div class="row">

                <div class="col-lg-4 mb-5 mb-lg-0">
                    <h4 class="text-uppercase mb-4">Egyéb elérhetőségeink:</h4>
                    <a class="btn btn-outline-light btn-social mx-1" href="https://www.facebook.com/AVisszateroEroSE"><i
                            class="fab fa-fw fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light btn-social mx-1" href="https://www.youtube.com/channel/UCrMR1P3YstaIVlz-ryOrnxw"><i class="fab fa-fw fa-youtube"></i></a>
                    
                    <a class="btn btn-outline-light btn-social mx-1" href="https://www.tiktok.com/@armwrestlinghungary"><i class="fab fa-fw fa-dribbble"></i></a>
                </div>

                <div class="col-lg-8">
                    <h4 class="text-uppercase mb-4">&nbsp;</h4>
                    <p class="lead mb-0 text-left">&nbsp;</p>
                </div>
            </div>
        </div>
    </footer>

    <div class="copyright py-4 text-center text-white">
        <div class="container"><small>Visszatérő Erő Sportegyesület ©2023</small></div>
    </div>

    <div class="scroll-to-top d-lg-none position-fixed">
        <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top"><i
                class="fa fa-chevron-up"></i></a>
    </div>
    </body>
</html>
