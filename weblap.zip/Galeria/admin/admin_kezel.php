<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Visszatérő Erő Sportegyesület weboldala" />
    <meta name="author" content="Visszatérő Erő Sport Egyesület." />

  
    <link rel="apple-touch-icon" sizes="180x180" href="../../web/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="../../web/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="../../web/favicon-16x16.png">
	<link rel="manifest" href="site.webmanifest">
	<link rel="mask-icon" href="safari-pinned-tab.svg" color="#5bbad5">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="theme-color" content="#ffffff">

  
    <title>Visszatérő Erő Sportegyesület</title>

    <!-- Ikonkészlet -->
    <script src="../../web/assets/fa-all.js"></script>
    <!-- Bootrsap CSS -->
    <link href="../../web/assets/bootstrap.css" rel="stylesheet" />


    <link href="../../web/visszatero.css" rel="stylesheet" />
</head>

<body id="page-top">

    <!-- Navigáció -->
    <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand js-scroll-trigger" href="#page-top">Visszatérő Erő Sport Egyesület</a>
            <button
                class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded"
                type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive"
                aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
               
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger"
                            href="../../web/index.php">Kezdőlap</a>
                    </li>
                    <li class="nav-item "><a class="nav-link rounded js-scroll-trigger" href="../../web/index.php#rolunk">Rólunk</a>
                    </li>
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../../naptar/index.html">Naptár</a>
                    </li>
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../../web/index.php#tamogatoink">Támogatóink</a>
                    </li>
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../index.php">Galéria</a>
                    </li>
					                   
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../../web/index.php#kapcsolat">Kapcsolat</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Fejléc -->
    <header class="masthead bg-primary text-white text-center">
        <div class="container d-flex align-items-center flex-column">
            <!-- Masthead Avatar Image-->
                       <!-- Masthead Heading-->
          <h1><strong>Visszatérő Erő Sport Egyesület</strong></h1>
            
            <!-- Icon Divider-->
            <div class="divider-custom divider-light">
                <div class="divider-custom-line"></div>
                <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                <div class="divider-custom-line"></div>
          </div>
            <!-- Masthead Subheading-->
            <p class="masthead-subheading font-weight-light mb-0">Képek adminisztrálása</p>
      </div>
    </header>
<?php
    include '../csatol/kapcsolat.php';
    session_start();
  // if (!isset($_SESSION['admin'])) header("Location: ../index.php");
    
    $sql = "SELECT * FROM admin";
    $result = $conn->query($sql);
    $uzen = "";
    
    if ( isset($_POST['azon']) && isset($_POST['jelszo']) ){
        $azon = $_POST['azon'];
        $jelszo = md5($_POST['jelszo']);
        $sql_admin = "SELECT * FROM admin WHERE azon = '$azon'";
        $keres = $conn->query($sql_admin);
        if ($keres->num_rows > 0){
            $uzen = "Ez az admin már szerepel az adatbázisban.";
        }
        else {
            $sql_rogzit = "INSERT INTO admin (azon, jelszo) VALUES ('$azon', '$jelszo')";
            $admin_rogzit = $conn->query($sql_rogzit);
            if ($admin_rogzit) $uzen = "Az admin rögzítése sikeres.";
            else $uzen = "Nem sikerült az admin rögzítése.";
        }
    }
?>
<section class="page-section" id="galeria2">
        <div class="container">

            <h2>Admin felvétele</h2>
        <form action="<?php print $_SERVER['PHP_SELF']; ?>" method="post">
            <table>
                <tr>
                    <td>Azon: </td>
                    <td><input type="text" name="azon" size="20"></td>
                </tr>
                <tr>
                    <td>Jelszó: </td>
                    <td><input type="password" name="jelszo" size="20"></td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" value="Mentés" name="ment"></td>
                </tr>
            </table>
        </form>
        
        <p><?php echo $uzen ?></p>
			<p><a href="index.php">Vissza az adminisztrációs felületre </a></p>
<p>&nbsp;</p>
		<!-- Footer-->
    <footer class="footer text-center">
        <div class="container">
            <div class="row">

                <div class="col-lg-4 mb-5 mb-lg-0">
                    <h4 class="text-uppercase mb-4">Egyéb elérhetőségeink:</h4>
                    <a class="btn btn-outline-light btn-social mx-1" href="https://www.facebook.com/AVisszateroEroSE"><i
                            class="fab fa-fw fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light btn-social mx-1" href="https://www.youtube.com/channel/UCrMR1P3YstaIVlz-ryOrnxw"><i class="fab fa-fw fa-youtube"></i></a>
                    
                    <a class="btn btn-outline-light btn-social mx-1" href="https://www.tiktok.com/@armwrestlinghungary"><i class="fab fa-fw fa-dribbble"></i></a>
                </div>

                <div class="col-lg-8">
                    <h4 class="text-uppercase mb-4">&nbsp;</h4>
                    <p class="lead mb-0 text-left">&nbsp;</p>
                </div>
            </div>
        </div>
    </footer>

    <div class="copyright py-4 text-center text-white">
        <div class="container"><small>Visszatérő Erő Sportegyesület ©2023</small></div>
    </div>

    <div class="scroll-to-top d-lg-none position-fixed">
        <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top"><i
                class="fa fa-chevron-up"></i></a>
    </div>
    </body>
</html>
