<?php
    include 'csatol/kapcsolat.php';
?>

<!DOCTYPE html>
<html lang="hu">
    <head>
         <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Visszatérő Erő Sportegyesület weboldala" />
    <meta name="author" content="Visszatérő Erő Sport Egyesület." />
		<link rel="apple-touch-icon" sizes="180x180" href="../web/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="../web/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="../web/favicon-16x16.png">
	<link rel="manifest" href="site.webmanifest">
	<link rel="mask-icon" href="safari-pinned-tab.svg" color="#5bbad5">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="theme-color" content="#ffffff">

        <title>Visszatérő Erő Sport Egyesület</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <link href="../web/visszatero.css" rel="stylesheet" type="text/css" />
		
        <link href="stilus/alap.css" rel="stylesheet" type="text/css">

	
		 <!-- Ikonkészlet -->
    <script src="../web/assets/fa-all.js"></script>
    <!-- Bootrsap CSS -->
    <link href="../web/assets/bootstrap.css" rel="stylesheet" />
    <style type="text/css">
    /*body,td,th {
    font-family: Lato, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
}*/
 
    </style>
    </head>
    <body id="page-top">
		<!-- Navigáció -->
    <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand js-scroll-trigger" href="#page-top">Visszatérő Erő Sport Egyesület</a>
            <button
                class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded"
                type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive"
                aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
               
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger"
                            href="../web/index.php">Kezdőlap</a>
                    </li>
                    <li class="nav-item "><a class="nav-link rounded js-scroll-trigger" href="../web/index.php#rolunk">Rólunk</a>
                    </li>
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../naptar/index.html">Naptár</a>
                    </li>
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../web/index.php#tamogatoink">Támogatóink</a>
                    </li>
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="index.php#galeria">Galéria</a>
                    </li>
					                   
                    <li class="nav-item"><a class="nav-link rounded js-scroll-trigger" href="../web/index.php#kapcsolat">Kapcsolat</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Fejléc -->
    <header class="masthead bg-primary text-white text-center">
        <div class="container d-flex align-items-center flex-column">
            <!-- Masthead Avatar Image-->
            <!-- Masthead Heading-->
          <h1><strong>Visszatérő Erő Sport Egyesület</strong></h1>
            
            <!-- Icon Divider-->
            <div class="divider-custom divider-light">
                <div class="divider-custom-line"></div>
                <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                <div class="divider-custom-line"></div>
          </div>
            <!-- Masthead Subheading-->
          <p class="masthead-subheading font-weight-light mb-0">Köszönjük, hogy megnézi a képeinket!</p>
      </div>
    </header>

  <section class="page-section szolgaltatasok" id="galeria">
        <div class="container">

            
            <h2 class="page-section-heading text-center text-uppercase text-secondary">KÉPEK</h2>

            <div class="divider-custom divider-light">
                <div class="divider-custom-line"></div>
                <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                <div class="divider-custom-line"></div>
            </div>

         </div>   
 </div>  
</section>      
	 <section class="page-section" id="galeria2">
        <div class="container">

<?php
    $kategoria_sql = "SELECT * FROM kategoria";
    $kategoria_keres = $conn -> query($kategoria_sql);
    if ($kategoria_keres -> num_rows > 0){
        
        while ($egyKat = $kategoria_keres->fetch_assoc()){
            
?>
            <div class="row">
                <div class="col">
                    <h2><?php echo $egyKat['neve'] ?></h2>
<?php
            $kategoria_id = $egyKat['id'];
            $kategoria_neve = $egyKat['neve'];
            $kepek_sql = "SELECT * FROM kepek WHERE kategoria_id = '$kategoria_id' ORDER BY sorszam";
            $kepek_keres = $conn ->query($kepek_sql);
            if ($kepek_keres -> num_rows > 0){
                while ($kep = $kepek_keres -> fetch_assoc()){
                    $eleres = "kepek/" . $kategoria_neve . "/" . $kep['neve'];
?>
                    <img src="<?php echo $eleres ?>">
<?php                    
                }
            }
            else {
 ?>
            
                    <p>Ebbe a kategóriába még nem töltöttek fel képeket. Kérjük nézzen vissza...</p>
                
 <?php
            }
 ?>
                    <p><?php echo $egyKat['leiras'] ?></p>
                </div>
            </div>         
 <?php           
        }
        
    }
    else {
?>
            <div class="row">
                <div class="col">
                    Elnézést, a galéria feltöltés alatt van.
                </div>
            </div>
<?php            
    }
    
?>            
        </div>
		 </div>
	</section>
<!-- Footer-->
    <footer class="footer text-center">
        <div class="container">
            <div class="row">

                <div class="col-lg-4 mb-5 mb-lg-0">
                    <h4 class="text-uppercase mb-4">Egyéb elérhetőségeink:</h4>
                    <a class="btn btn-outline-light btn-social mx-1" href="https://www.facebook.com/AVisszateroEroSE"><i
                            class="fab fa-fw fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light btn-social mx-1" href="https://www.youtube.com/channel/UCrMR1P3YstaIVlz-ryOrnxw"><i class="fab fa-fw fa-youtube"></i></a>
                    
                    <a class="btn btn-outline-light btn-social mx-1" href="https://www.tiktok.com/@armwrestlinghungary"><i class="fab fa-fw fa-dribbble"></i></a>
                </div>

                <div class="col-lg-8">
                    <h5 class="text-uppercase mb-4"><a href="admin/index.php">Adminisztrációs felület</a></h4>
                    <p class="lead mb-0 text-left">&nbsp;</p>
                </div>
            </div>
        </div>
    </footer>

    <div class="copyright py-4 text-center text-white">
        <div class="container"><small>Visszatérő Erő Sportegyesület ©2023</small></div>
    </div>

    <div class="scroll-to-top d-lg-none position-fixed">
        <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top"><i
                class="fa fa-chevron-up"></i></a>
    </div>

    </body>
</html>
